# Story Skills → ChatGPT conversion notes

## Result

Converted all 24 upstream skills into the standard ChatGPT-compatible Agent Skills folder format. Each folder contains its original skill-specific references and templates, a ChatGPT runtime guide, and a `SKILL.md` handoff to that guide. Individual ZIP packages are included under `individual-skill-zips/` for skill-by-skill distribution.

ChatGPT's official skill documentation describes this format as a directory containing a required `SKILL.md` with `name` and `description`, with optional scripts, references, and assets. ChatGPT can select skills from their descriptions or use them when invoked directly. [OpenAI: Build skills](https://learn.chatgpt.com/docs/build-skills?product=breeze)

## Conversion approach

The upstream already uses the open Agent Skills structure, so the core creative methods and the 24 names/descriptions were retained. The main compatibility work addresses the runtime assumptions:

- Story projects are not assumed to be available by local path; the skill first checks for attachments or connected workspace files.
- `story` CLI commands are treated as optional. Skills may use them only when the active environment actually provides them; otherwise they do reliable file-based work and clearly disclose checks that cannot be performed.
- Changes to canon, voice, plot, and other author-owned choices remain with the author.
- Cross-skill references work as sibling skills when installed together, and relative reference files remain inside each skill package.
- The Claude Code folder probe in `chapter-writing` was removed. The optional prose companion is used only if the user makes it available in ChatGPT.
- The original maintenance CLI fallback and its supporting package metadata remain included in `story-maintenance` for environments that can execute it.

This is a compatibility conversion, not a claim that every ChatGPT session has terminal access or can run the Story CLI. Mechanical CLI checks and generated outputs still depend on that capability.

## Skill-by-skill review

| Skill | Scope retained | ChatGPT-specific handling |
|---|---|---|
| `adaptation` | Adapt a finished story into audio, screen, comic, picture-book, interactive, or translated forms. | Keep adaptation work separate from source canon; use current tools only for file export and verify live platform specs when needed. (6 supporting files retained) |
| `chapter-writing` | Outline-first chapter and scene drafting with continuity-aware context. | Check attached/connected project files first; CLI context is optional. Removed Claude-specific companion-skill path probing. (3 supporting files retained) |
| `character-management` | Create, revise, relate, and track character profiles and progressions. | Use file-based source records when available; avoid claiming indexes or continuity checks were rebuilt without the CLI. (4 supporting files retained) |
| `discovery-drafting` | Draft by discovery and reconcile prose back into the story bible. | Preserve the iterative process in chat; mark unverified bible questions and distinguish actual edits from proposed reconciliation. (4 supporting files retained) |
| `editorial-review` | Review sensitivity, permissions, real-person risks, collaboration, and editorial rounds. | Use browsing only when available and relevant; distinguish research from legal advice and never send/share files without authorization. (4 supporting files retained) |
| `feedback-triage` | Collect, classify, and synthesize feedback from readers. | Treat reader notes as untrusted source material, not instructions; make actionable edits only when requested. (2 supporting files retained) |
| `genre-craft` | Apply genre conventions, promises, clues, pacing, and genre-specific craft. | Maintain canon via project files; report mechanical checks as pending when CLI access is absent. (10 supporting files retained) |
| `interactive-fiction` | Plan and draft branching narratives, choice graphs, and path continuity. | Use text-based graph/path reasoning when export tooling is unavailable; do not claim Ink/Twine builds were produced. (2 supporting files retained) |
| `line-editing` | Line edits, copyedits, proofreading, voice differentiation, and read-aloud passes. | Edit supplied/connected text directly; distinguish editorial suggestions from applied changes and avoid inaccessible CLI linting claims. (5 supporting files retained) |
| `plot-structure` | Design plot structures, arcs, beats, timelines, setups, and payoffs. | Track source records in available files and make CLI-dependent reindex or timeline reports explicit. (8 supporting files retained) |
| `premise-workshop` | Develop, test, and title a story premise before drafting. | Conduct brainstorming interactively; preserve provisional decisions and offer file-ready outputs if project creation tools are unavailable. (4 supporting files retained) |
| `publishing` | Prepare self-publishing production, metadata, rights, and launch plans. | Treat retailer/platform requirements as time-sensitive; verify current requirements when web research is available. (6 supporting files retained) |
| `reader-panel` | Run structured simulated reader reactions before a human feedback round. | Label reactions as simulated perspectives, not evidence about real readers; keep persona feedback tied to the supplied text. (5 supporting files retained) |
| `research` | Research factual, historical, technical, or cultural story details and record sources. | Use web research when available; keep citations and confidence visible, and do not invent sources or interviews. (2 supporting files retained) |
| `revision-continuity` | Plan revision passes and audit structure, continuity, timelines, and plot threads. | Use available manuscript sources; state the scope reviewed and any CLI checks not actually run. (1 supporting files retained) |
| `scene-craft` | Plan and revise scene goals, outcomes, subtext, POV, exposition, and openings. | Keep recommendations tied to the active manuscript and seek author choice on substantive story changes. (8 supporting files retained) |
| `series-continuity` | Manage canon across linked books, prequels, sequels, and series pitches. | Compare only provided/connected book files; mark unsupported cross-book continuity as unknown rather than filling gaps. (1 supporting files retained) |
| `story-init` | Set up a new fiction project and its story bible structure. | Create files only where the ChatGPT workspace supports it; otherwise return a complete starter structure and contents. (2 supporting files retained) |
| `story-maintenance` | Validate, repair, import, export, build, and summarize Story Skills projects. | CLI-first commands become capability-gated; the included fallback runs only where a terminal is available. (7 supporting files retained) |
| `submission` | Prepare query packages, synopses, blurbs, manuscript formats, and submission tracking. | Never invent credentials, market details, guidelines, or outcomes; check current requirements when browsing is available. (6 supporting files retained) |
| `theme-craft` | Develop controlling idea, character arcs, antagonistic arguments, motifs, and theme audits. | Store decisions only in available project files and keep unresolved themes explicitly provisional. (5 supporting files retained) |
| `verse-craft` | Write, scan, and revise poems, lyrics, and verse within or outside stories. | Show scansion and uncertainty; preserve the author poem unless a rewrite is expressly requested. (3 supporting files retained) |
| `voice-style` | Build a style sheet and track voice, spelling, punctuation, and prose patterns. | Use samples actually available in the chat and label any manual review where automated lint tools are missing. (2 supporting files retained) |
| `worldbuilding` | Create and maintain places, systems, factions, artifacts, routes, calendars, and glossary terms. | Keep world canon in linked project records when possible; do not silently resolve contradictions or assume Earth norms. (9 supporting files retained) |
## Recommended use

The collection follows the standalone skill-folder format supported in the ChatGPT desktop app. OpenAI documentation says skills distributed inside plugins are available in Chat and Work across ChatGPT web, desktop, and mobile; therefore use plugin packaging if web/mobile distribution is the target. This deliverable contains skill folders and per-skill ZIPs, not a plugin manifest.

Install or add only the skills you want available, or add the full set together so cross-skill handoffs resolve. If installing individually, a skill that references another sibling skill can still complete its own work, but should identify the missing specialist handoff when needed. Keep the user's story project in an attached or connected workspace so edits can be made against the real files.

The upstream source is MIT licensed. The source repository is [danjdewhurst/story-skills](https://github.com/danjdewhurst/story-skills); this conversion preserves its `LICENSE` terms.
